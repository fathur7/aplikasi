import 'package:flutter/material.dart';
import 'package:flutter/painting.dart';
import 'package:uts_fujifilm_fathurrohman/deskripsi.dart';

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        centerTitle: true,
        backgroundColor: Color(0xffffffff),
        title: Image.asset(
          "images/logoAppBar.png",
        width: 150.0,
        height: 70.0,
        ),
        leading: Image.asset(
          "images/menu.png",
        ),
        actions: <Widget>[
          Padding(
            padding: EdgeInsets.only(right: 20.0),
            child: GestureDetector(
              onTap: () {},
              child: Image.asset(
                "images/keranjang.png",
              ),
            )
          ),
        ],
      ),
      body: ListView(
        children: <Widget>[
          Padding(
            padding: EdgeInsets.only(top: 30, right: 25, left: 25),
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black, borderRadius: BorderRadius.circular(30)
              ),
              child: TextField(
                style: TextStyle(color: Colors.white),
                cursorColor: Colors.white,
                decoration: InputDecoration(
                  border: InputBorder.none,
                  errorBorder: InputBorder.none,
                  enabledBorder: InputBorder.none,
                  contentPadding: EdgeInsets.all(15),
                  hintText: 'Search',
                  hintStyle: TextStyle(color: Colors.white)
                ),
              ),
            ),
          ),

          ListInstax(
            judul: "Limited Edition",
            jenis: "Mini Mint 7+",
            harga: "\$ 49.90",
            gambar: "images/mint.png",
            warna: Color(0xff70b1a1),
          ),

          ListInstax(
            judul: "Limited Edition",
            jenis: "Mini Blue 7+",
            harga: "\$ 50.90",
            gambar: "images/blue.png",
            warna: Color(0xff77a0c6),
          ),

          ListInstax(
            judul: "Limited Edition",
            jenis: "Mini Choral 7+",
            harga: "\$ 51.90",
            gambar: "images/choral.png",
            warna: Color(0xffb0463c),
          ),

          ListInstax(
            judul: "Limited Edition",
            jenis: "Mini Pink 7+",
            harga: "\$ 52.90",
            gambar: "images/pink.png",
            warna: Color(0xffcf9496),
          ),

          ListInstax(
            judul: "Limited Edition",
            jenis: "Mini Lavender 7+",
            harga: "\$ 53.90",
            gambar: "images/lavender.png",
            warna: Color(0xff855f8c),
          ),
        ],
      ),
    );
  }
}

class ListInstax extends StatelessWidget {
  
ListInstax ({
  required this.judul,
  required this.jenis,
  required this.harga,
  required this.gambar,
  required this.warna,
});

final String judul;
final String jenis;
final String harga;
final String gambar;
final warna;

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.only(top: 20, right: 20, left: 20),
      padding: EdgeInsets.only(top: 15, left: 10, bottom: 15),
      decoration: BoxDecoration(
        color: warna,
        borderRadius: BorderRadius.circular(30)
      ),
      child: Center(
        child: Row(
          children: <Widget>[
            Container(
              width: 150,
              margin: EdgeInsets.only(right: 100),
              child: Column(
                children: <Widget>[
                  Text(judul, style: TextStyle(fontSize: 10.0, color: Colors.white),),
                  Container(
                    margin: EdgeInsets.only(top: 20, bottom: 20),
                    child: Row(
                      children: <Widget>[
                        Text("Instax ", style: TextStyle(color: Colors.white),),
                        Text(jenis, style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),),
                      ],
                    ),
                  ),
                  Text(harga, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20.0, color: Colors.white),),
                  RaisedButton(
                    shape: StadiumBorder(),
                    child: Text("BUY", style: TextStyle(fontWeight: FontWeight.bold, color: warna),),
                    onPressed: (){
                      Navigator.push(
                        context,
                        MaterialPageRoute(builder: (context) => DeskripsiItem(
                          judul: judul,
                          jenis: jenis,
                          harga: harga,
                          gambar: gambar,
                          warna: warna,
                        )),
                      );
                    }
                  )
                ],
              ),
            ),
            Container(
              margin: EdgeInsets.only(left: 50),
              child: Image.asset(
                gambar,
                width: 120.0,
                height: 120.0,
              ),
            )
          ],
        ),
      ),
    );
  }
}