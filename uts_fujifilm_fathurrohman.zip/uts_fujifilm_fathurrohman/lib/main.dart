import 'package:flutter/material.dart';
import 'package:uts_fujifilm_fathurrohman/splashscreen.dart';

void main() {
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Splash Screen',
    home: SplashScreenPage(),
  ));
}