package com.example.uts_fujifilm_fathurrohman

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
